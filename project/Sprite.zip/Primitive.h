#pragma once

#include <cstdint>
#include <d3d12.h>
#include <list>
#include <wrl.h>

#include "MyMath.h"
#include "DirectXCommon.h"
#include "TextureManager.h"

class Primitive
{
public:
    static const uint32_t kMaxParticles = 1024;

    struct Particle
    {
        Transform transform;
        Vector3 velocity;
        Vector4 color;
        float lifeTime;
        float maxTime;
    };

    struct InstanceData
    {
        Matrix4x4 WVP;
        Vector4 color;
    };

    struct VertexData
    {
        Vector4 position;
        Vector2 texcoord;
        Vector3 normal;
    };

public:
    void Initialize(
        DirectXCommon* dxCommon,
        TextureManager* textureManager
    );

    void Update(
        const Matrix4x4& viewMatrix,
        const Matrix4x4& projectionMatrix
    );

    void Draw();

    void Emit(
        const Vector3& position,
        uint32_t count
    );

    void SetIsActive(bool isActive)
    {
        isActive_ = isActive;
    }

    bool GetIsActive() const
    {
        return isActive_;
    }

private:
    void CreateRootSignature();
    void CreatePipelineState();
    void CreateMesh();

private:
    DirectXCommon* dxCommon_ = nullptr;
    TextureManager* textureManager_ = nullptr;

    Microsoft::WRL::ComPtr<ID3D12RootSignature>
        rootSignature_;

    Microsoft::WRL::ComPtr<ID3D12PipelineState>
        pipelineState_;

    Microsoft::WRL::ComPtr<ID3D12Resource>
        vertexBuffer_;

    D3D12_VERTEX_BUFFER_VIEW
        vertexBufferView_{};

    Microsoft::WRL::ComPtr<ID3D12Resource>
        instancingBuffer_;

    D3D12_VERTEX_BUFFER_VIEW
        instancingBufferView_{};

    InstanceData* instancingDataMapped_ = nullptr;

    uint32_t textureHandle_ = 0;

    std::list<Particle> particles_;

    bool isActive_ = true;
};