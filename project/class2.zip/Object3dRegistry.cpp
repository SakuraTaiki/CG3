#include "Object3dRegistry.h"
#include <cassert>

void Object3dRegistry::Initialize(Object3dCommon* object3dCommon) {
    assert(object3dCommon);
    object3dCommon_ = object3dCommon;
}

void Object3dRegistry::Finalize() {
    objects_.clear();
    object3dCommon_ = nullptr;
}

Object3d* Object3dRegistry::Create(
    Model* model,
    const Vector3& position,
    const Vector3& rotation,
    const Vector3& scale) {

    assert(object3dCommon_);
    assert(model);

    std::unique_ptr<Object3d> object = std::make_unique<Object3d>();
    object->Initialize(object3dCommon_);
    object->SetModel(model);
    object->SetPosition(position);
    object->SetRotation(rotation);
    object->SetScale(scale);

    Object3d* result = object.get();
    objects_.push_back(std::move(object));

    return result;
}

void Object3dRegistry::Update() {
    for (auto& object : objects_) {
        object->Update();
    }
}

void Object3dRegistry::Draw() {
    for (auto& object : objects_) {
        object->Draw();
    }
}