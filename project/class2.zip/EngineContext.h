#pragma once

class WinApp;
class DirectXCommon;
class Input;
class SrvManager;
class TextureManager;
class SpriteCommon;
class Object3dCommon;
class ParticleManager;
class ImGuiManager;
class Camera;

struct EngineContext {
    WinApp* winApp = nullptr;
    DirectXCommon* dxCommon = nullptr;
    Input* input = nullptr;
    SrvManager* srvManager = nullptr;
    TextureManager* textureManager = nullptr;
    SpriteCommon* spriteCommon = nullptr;
    Object3dCommon* object3dCommon = nullptr;
    ParticleManager* particleManager = nullptr;
    ImGuiManager* imGuiManager = nullptr;
    Camera* camera = nullptr;
};