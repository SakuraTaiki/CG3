#pragma once
#include <memory>

#include "EngineContext.h"
#include "WinApp.h"
#include "DirectXCommon.h"
#include "Input.h"
#include "SrvManager.h"
#include "TextureManager.h"
#include "SpriteCommon.h"
#include "Object3dCommon.h"
#include "ParticleManager.h"
#include "ImGuiManager.h"
#include "camera.h"

class GameSystem {
public:
    void Initialize();
    void Finalize();

    bool IsRunning() const;

    EngineContext& GetContext() { return context_; }

private:
    std::unique_ptr<WinApp> winApp_;
    std::unique_ptr<DirectXCommon> dxCommon_;
    std::unique_ptr<Input> input_;
    std::unique_ptr<SrvManager> srvManager_;
    std::unique_ptr<TextureManager> textureManager_;
    std::unique_ptr<SpriteCommon> spriteCommon_;
    std::unique_ptr<Object3dCommon> object3dCommon_;
    std::unique_ptr<ParticleManager> particleManager_;
    std::unique_ptr<ImGuiManager> imGuiManager_;
    std::unique_ptr<Camera> camera_;

    EngineContext context_{};
};