#include "RenderController.h"
#include "ParticleManager.h"
#include "ImGuiManager.h"

void RenderController::Draw(
    EngineContext* context,
    Object3dRegistry* objectRegistry,
    Sprite* sprite,
    Skybox* skybox) {

    context->dxCommon->PreDrawForRenderTexture();

    context->srvManager->PreDraw();

    context->object3dCommon->PreDraw();

    objectRegistry->Draw();

    if (skybox) {
        skybox->Draw();
    }

    context->particleManager->Draw();

    context->dxCommon->PreDraw();

    context->dxCommon->DrawRenderTextureToSwapChain();

    context->srvManager->PreDraw();

    context->spriteCommon->PreDraw();

    if (sprite) {
        sprite->Draw();
    }

    context->imGuiManager->Draw();

    context->dxCommon->PostDraw();
}