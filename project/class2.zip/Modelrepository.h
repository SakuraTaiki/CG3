#pragma once
#include <memory>
#include <string>
#include <unordered_map>

#include "Model.h"

class DirectXCommon;
class TextureManager;

class ModelRepository {
public:
    void Initialize(DirectXCommon* dxCommon, TextureManager* textureManager);
    void Finalize();

    Model* Load(const std::string& filename);
    Model* Find(const std::string& filename) const;

private:
    DirectXCommon* dxCommon_ = nullptr;
    TextureManager* textureManager_ = nullptr;

    std::unordered_map<std::string, std::unique_ptr<Model>> models_;
};