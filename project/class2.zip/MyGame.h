#pragma once

#include <memory>

#include "GameSystem.h"
#include "ModelRepository.h"
#include "Object3dRegistry.h"
#include "SampleSceneBuilder.h"
#include "SoundController.h"
#include "RenderController.h"

#include "Sprite.h"
#include "Skybox.h"

class MyGame {
public:
    void Initialize();
    void Update();
    void Draw();
    void Finalize();

    bool IsRunning() { return gameSystem_.IsRunning(); }

private:
    void InitializeAssets();
    void InitializeScene();
    void UpdateWorld();
    void UpdateImGui();

private:
    GameSystem gameSystem_;

    ModelRepository modelRepository_;
    Object3dRegistry objectRegistry_;
    SampleSceneBuilder sampleSceneBuilder_;
    SoundController soundController_;
    RenderController renderController_;

    std::unique_ptr<Sprite> sprite_;
    std::unique_ptr<Skybox> skybox_;
};