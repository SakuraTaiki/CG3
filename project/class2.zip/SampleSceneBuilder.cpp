#include "SampleSceneBuilder.h"
#include <cassert>

void SampleSceneBuilder::Build(
    ModelRepository* modelRepository,
    Object3dRegistry* objectRegistry) {

    assert(modelRepository);
    assert(objectRegistry);

    Model* modelPlane = modelRepository->Load("plane.obj");
    Model* modelAxis = modelRepository->Load("axis.obj");

    Object3d* floor = objectRegistry->Create(
        modelPlane,
        { 0.0f, 0.0f, 0.0f }
    );
    floor->SetScale({ 10.0f, 1.0f, 10.0f });

    objectRegistry->Create(
        modelAxis,
        { 2.0f, 0.0f, 0.0f }
    );

    objectRegistry->Create(
        modelAxis,
        { -2.0f, 0.0f, 0.0f }
    );
}