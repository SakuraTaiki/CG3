#pragma once

#include "ModelRepository.h"
#include "Object3dRegistry.h"

class SampleSceneBuilder {
public:
    void Build(ModelRepository* modelRepository, Object3dRegistry* objectRegistry);
};