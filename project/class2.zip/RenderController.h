#pragma once

#include "EngineContext.h"
#include "Object3dRegistry.h"
#include "Sprite.h"
#include "Skybox.h"

class RenderController {
public:
    void Draw(
        EngineContext* context,
        Object3dRegistry* objectRegistry,
        Sprite* sprite,
        Skybox* skybox);
};