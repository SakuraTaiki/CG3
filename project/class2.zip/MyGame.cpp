#include "MyGame.h"

#ifdef USE_IMGUI
#include "externals/imgui/imgui.h"
#endif

void MyGame::Initialize() {
    gameSystem_.Initialize();

    EngineContext& context = gameSystem_.GetContext();

    modelRepository_.Initialize(
        context.dxCommon,
        context.textureManager
    );

    objectRegistry_.Initialize(
        context.object3dCommon
    );

    soundController_.Initialize();

    InitializeAssets();
    InitializeScene();
}

void MyGame::InitializeAssets() {
    EngineContext& context = gameSystem_.GetContext();

    uint32_t texHandle = context.textureManager->LoadTexture("Resources/uvChecker.png");

    sprite_ = std::make_unique<Sprite>();
    sprite_->Initialize(context.spriteCommon, texHandle);

    skybox_ = std::make_unique<Skybox>();
    skybox_->Initialize(
        context.dxCommon,
        context.textureManager,
        "Resources/skybox/rostock_laage_airport_4k.dds"
    );
    skybox_->SetScale({ 100.0f, 100.0f, 100.0f });
}

void MyGame::InitializeScene() {
    sampleSceneBuilder_.Build(
        &modelRepository_,
        &objectRegistry_
    );
}

void MyGame::Update() {
    EngineContext& context = gameSystem_.GetContext();

    context.input->Update();

    if (context.input->TriggerKey(DIK_SPACE)) {
        context.particleManager->Emit({ 0.0f, 0.0f, 0.0f }, 10);
    }

    soundController_.Update(context.input);

    UpdateWorld();
    UpdateImGui();
}

void MyGame::UpdateWorld() {
    EngineContext& context = gameSystem_.GetContext();

    context.camera->Update();

    const Matrix4x4& view = context.camera->GetViewMatrix();
    const Matrix4x4& projection = context.camera->GetProjectionMatrix();

    objectRegistry_.Update();

    if (skybox_) {
        skybox_->SetCamera(view, projection);
        skybox_->Update();
    }

    if (sprite_) {
        sprite_->Update();
    }

    context.particleManager->Update(view, projection);
}

void MyGame::UpdateImGui() {
#ifdef USE_IMGUI
    EngineContext& context = gameSystem_.GetContext();

    context.imGuiManager->Begin();

    soundController_.DrawImGui();

    context.imGuiManager->End();
#endif
}

void MyGame::Draw() {
    EngineContext& context = gameSystem_.GetContext();

    renderController_.Draw(
        &context,
        &objectRegistry_,
        sprite_.get(),
        skybox_.get()
    );
}

void MyGame::Finalize() {
    skybox_.reset();
    sprite_.reset();

    soundController_.Finalize();

    objectRegistry_.Finalize();
    modelRepository_.Finalize();

    gameSystem_.Finalize();
}