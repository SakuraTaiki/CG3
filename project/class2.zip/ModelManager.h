#pragma once
#include <string>
#include <unordered_map>
#include <memory>

#include "Model.h"
#include "Object3dCommon.h"

class ModelManager {
public:
    static void Initialize(Object3dCommon* common);
    static void Finalize();

    // モデルを読み込んでキャッシュする
    static Model* Load(const std::string& modelName);

    // すでに読み込み済みのモデルを取得する
    static Model* Find(const std::string& modelName);

private:
    static Object3dCommon* common_;
    static std::unordered_map<std::string, std::unique_ptr<Model>> models_;
};