#pragma once
#include <memory>
#include <vector>

#include "Object3d.h"
#include "Model.h"
#include "MyMath.h"

class Object3dRegistry {
public:
    void Initialize(Object3dCommon* object3dCommon);
    void Finalize();

    Object3d* Create(
        Model* model,
        const Vector3& position,
        const Vector3& rotation = { 1.57f, 0.0f, 0.0f },
        const Vector3& scale = { 1.0f, 1.0f, 1.0f });

    void Update();
    void Draw();

private:
    Object3dCommon* object3dCommon_ = nullptr;
    std::vector<std::unique_ptr<Object3d>> objects_;
};