#include "Modelrepository.h"
#include "DirectXCommon.h"
#include "TextureManager.h"
#include <cassert>

void ModelRepository::Initialize(DirectXCommon* dxCommon, TextureManager* textureManager) {
    assert(dxCommon);
    assert(textureManager);

    dxCommon_ = dxCommon;
    textureManager_ = textureManager;
}

void ModelRepository::Finalize() {
    models_.clear();
    dxCommon_ = nullptr;
    textureManager_ = nullptr;
}

Model* ModelRepository::Load(const std::string& filename) {
    auto it = models_.find(filename);
    if (it != models_.end()) {
        return it->second.get();
    }

    std::unique_ptr<Model> model(
        Model::CreateFromOBJ(dxCommon_, "Resources", filename, textureManager_)
    );

    Model* result = model.get();
    models_[filename] = std::move(model);

    return result;
}

Model* ModelRepository::Find(const std::string& filename) const {
    auto it = models_.find(filename);
    if (it == models_.end()) {
        return nullptr;
    }

    return it->second.get();
}