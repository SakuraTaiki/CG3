#include "Skelton.h"
#include <cassert>

int32_t CreateJoint(
    const Node& node,
    const std::optional<int32_t>& parent,
    std::vector<Joint>& joints)
{
    Joint joint{};

    joint.name = node.name;
    joint.localMatrix = node.localMatrix;
    joint.skeletonSpaceMatrix = Math::MakeIdentity4x4();
    joint.transform = node.transform;
    joint.index = static_cast<int32_t>(joints.size());
    joint.parent = parent;

    joints.push_back(joint);

    for (const Node& child : node.children) {
        int32_t childIndex =
            CreateJoint(child, joint.index, joints);

        joints[joint.index].children.push_back(childIndex);
    }

    return joint.index;
}

Skeleton CreateSkeleton(const Node& rootNode) {
    Skeleton skeleton{};

    skeleton.root = CreateJoint(rootNode, std::nullopt, skeleton.joints);

    for (const Joint& joint : skeleton.joints) {
        skeleton.jointMap.emplace(joint.name, joint.index);
    }

    Update(skeleton);

    return skeleton;
}

void Update(Skeleton& skeleton) {
    for (Joint& joint : skeleton.joints) {
        joint.localMatrix =
            Math::MakeAffineMatrix(
                joint.transform.scale,
                joint.transform.rotate,
                joint.transform.translate);

        if (joint.parent) {
            joint.skeletonSpaceMatrix =
                Math::Multiply(
                    joint.localMatrix,
                    skeleton.joints[*joint.parent].skeletonSpaceMatrix);
        } else {
            joint.skeletonSpaceMatrix = joint.localMatrix;
        }
    }
}